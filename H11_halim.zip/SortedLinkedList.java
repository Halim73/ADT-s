/**
* This is a sorted linked list class that has the class invariant of always being sorted.
* it also implements the ISortedList interface
* @author Halim Acosta
*/
import java.util.*;
public class SortedLinkedList<E extends Comparable<E>> implements ISortedList<E>{
    private Node front;
    private Node back;
    private int size;
    
    /**
    * This constructor method will create an empty list
    */
    public SortedLinkedList(){
        back = front = null;
        size = 0;
    }
    /**
    * This method will return the head without consuming it
    * @return front.value
    * @throws NullPointerException for empty list
    */
    public E getHead(){
        if(front != null){
            return front.value;
        }
        throw new NullPointerException("Error! Empty list");
    }
    /**
    * This method will return the tail without consuming it
    * @return back.value
    * @throws NullPointerException for empty list
    */
    public E getTail(){
        if(back != null){
            return back.value;
        }
        throw new NullPointerException("Error! Empty list");
    }
    /**
    * This method will return the head with consuming it
    * @return temp.value
    * @throws NullPointerException for empty list
    */
    public E removeHead(){
        if(!isEmpty()){
            Node temp = front;
            front = front.next;
            size--;
            return temp.value;
        }
        throw new NullPointerException("Error! Empty list");
    }
    /**
    * This method will return the Tail with consuming it
    * @return temp.value
    * @throws NullPointerException for empty list
    */
    public E removeTail(){
        if(!isEmpty()){
            Node current = front;
            
            while(current.next != null){
                current = current.next;
            }
            Node temp = current;
            current = current.next;
            size--;
            return temp.value;
        }
        throw new NullPointerException("Error! Empty list");
    }
    /**
    * This method will remove the given value from the list
    * @param value the value to be removed from the list
    * @return true if the given value was successfully removed false if not
    */
    public boolean remove(E value){
        if(isEmpty()){
            return false;
        }
        
        Node current = front;
        if(current.value.equals(value)){
            current.next = current.next.next;
        }
        while(!current.next.value.equals(value)){
            current = current.next;
            if(current.value.equals(null)){
                return false;
            }
        }    
        current.next = current.next.next;
        size--;
        return true;
    }
    /**
    * This method will return the index of the given value
    * @param value the given value to be indexed
    * @return i the index of the value 0 if its at the front and -1 if its not found
    */
    public int indexOf(E value){
        Node current = front;
        
        if(front.value.equals(value)){
            return 0;
        }
        
        for(int i=1;i<=size;i++){
            current = current.next;
            
            if(current.value.equals(value)){
                return i;
            }
        }
        return -1;
    }
    /**
    * This method will check if the list is empty or not
    * @return size == 0
    */
    public boolean isEmpty(){
        return size == 0;
    }
    /**
    * This method will see if the value is contained in this list
    * @param value the value thats being checked for existence
    * @return true if the index is greater than or equal to 0 
    */
    public boolean contains(E value){
        return indexOf(value) >= 0;
    }
    /**
    * This method will add the corresponding value to the list
    * @param value the value to be added to the list with the invariance that it is always placed in sorted order
    */
    public void add(E value){
        if(front == null || (front.value).compareTo(value) >= 0){
            front = new Node(value,front);
        }else{
            Node current = front;
            while(current.next != null && (current.next.value).compareTo(value) < 0){
                current = current.next;
            }
            back = current.next = new Node(value,current.next);
            size++;
        }
    }
    /**
    * This method will add another ISortedList to this list
    * @param other the other list as long as it implements ISortedList interface
    */
    public void addAll(ISortedList<E> other){
        for(E e: other){
            add(e);
            size++;
        }
    }
    /**
    * This method will clear the whole list 
    */
    public void clear(){
        back = front = null;
        size = 0;
    }
    /**
    * this method will return the size of the list
    * return size the size of the list
    */
    public int size(){
        return size;
    }
    /**
    * This method will return an iterator 
    * @return LinkedIterator
    */
    public LinkedIterator iterator(){
        return new LinkedIterator();
    }
    /**
    * This method will return a string representation of the list
    * @return result the result of the compiled string 
    */
    public String toString(){
        if(isEmpty()){return "[]";}
        
        Node current = front;
        
        String result = "["+current.value;
        current = current.next;
        
        while(current != null){
            result += ", "+current.value;
            current = current.next;
        }
        result += "]";
        return result;
    }
    /**
    * This subclass will create the linked list iterator
    * @author Halim Acosta 
    */
    protected class LinkedIterator implements Iterator<E>{
            private Node current;
            private boolean removeOk;
            
            /**
            * This is the constructor method for the iterator 
            */
            public LinkedIterator(){
                current = front;
                removeOk = false;
            }
            /**
            * This method will return whether the iterator has more items to go through
            * @return true if the current value is not equal to null
            */
            public boolean hasNext(){
                return current != null;
            }
            /**
            * This method will return the next value in the list while advancing the iterator
            * @return data the value of the current value
            * @throws NoSuchElementException if the there isnt a next to have 
            */
            public E next(){
                if(!hasNext()){throw new NoSuchElementException();}
                
                E data = current.value;
                current = current.next;
                removeOk = true;
                return data;
            }
            /**
            * This method will remove the current value from the list 
            * @throws IllegalStateException if it isnt ok to remove the value
            */
            public void remove(){
                if(removeOk = false){throw new IllegalStateException();}
                current = current.next;
                size--;
                removeOk = false;
            }
        }
    /**
    * This class is a single linked node class 
    * @author Halim Acosta
    */
    protected class Node{
        E value;
        Node next;
        
        /**
        * This is the main constuctor method 
        * @param value the value that will be the value of the current node
        * @param next the value that will be the next node in the list
        */
        Node(E value,Node next){
            this.value = value;
            this.next = next;
        }
        /**
        * This is the default constructor if the next node is not currently known 
        * @param value the value of the current node
        */
        Node(E value){
            this(value,null);
        }
    }
}